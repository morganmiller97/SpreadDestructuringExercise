//Spread and Destructuring Exercise

// 1a 
const mcuShows = ['Loki',`Moon Knight`];
 console.log(mcuShows);

// 1b
const starWarsShows=[`The Mandalorian`, `The Book of Boba Fett`];

// 1c
const disneyPlusShows=[...mcuShows, ...starWarsShows, `The Beatles: Get Back`];

// 1d
console.log(disneyPlusShows);

// 2a
const netflixMovies = {
    action: `Extraction`,
    crime: `The Irishman`
};
console.log(netflixMovies);

// 2b
const amazonPrimeMovies = {
    action: 'The Tomorrow War',
    drama: 'One Night Miami'
};
console.log(amazonPrimeMovies);

// 2c 2d
const streamingMovies = {
    ...amazonPrimeMovies,
    ...netflixMovies,
    musical: 'Hamilton'
};
console.log(streamingMovies);

// 3a 
const disneyJunior= [
    `Mickey Mouse Clubhouse`, 
    `Spidey and His Amazing Friends`
];

// 3b 
const disneyJunior = [mickey, spidey];
console.log(disneyJunior);


